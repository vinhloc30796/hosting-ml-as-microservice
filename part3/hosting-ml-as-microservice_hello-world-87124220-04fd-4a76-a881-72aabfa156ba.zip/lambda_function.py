import json
print('Loading function')

def lambda_handler(event, context):
    """
    Input: 
    - event (dict): should include key 'name'
    - context (dict)
    Output:
    - greetings (str): 'Hello {name}!'
    """
    print('Received event: ' +
        json.dumps(event, indent=2))
    
    if 'name' in event:
        name = event['name']
    else:
        name = 'World'
    
    greetings = 'Hello ' + name + '!'
    print(greetings)
    
    return greetings