import json

def lambda_handler(event, context):
    """
    Input:
    - event: {'name': str, 'greet': str}
    - context: optional
    Output:
    - result (str): '{greet} {name}'
    """
    print()
    if 'name' in event:
        name = event['name']
    else:
        name = 'World'
    
    if 'greet' in event:
        greet = event['greet']
    else:
        greet = 'Hello'
    result = f"{greet} {name}!"
    print(result)
    return result
